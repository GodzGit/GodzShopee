<?php
    $usernamelogin = 'alok';
    $passwordlogin = 'jilong';
    // start sesi
    session_start();

    // isian
    $username = $_POST['username'];
    $password = $_POST['password'];

    // cek
    if ($username == $usernamelogin && $password == $passwordlogin) {
        session_start();
        header("location: menu.html");
    }
    else {
        header("location: index.html");
    }
?>